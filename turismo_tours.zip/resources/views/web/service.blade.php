<x-app-layout>
    
    <div class="my-16">
        @livewire('show-service')

    </div>
</x-app-layout>
