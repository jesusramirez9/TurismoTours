<x-app-layout>
    @livewire('show-post')
</x-app-layout>