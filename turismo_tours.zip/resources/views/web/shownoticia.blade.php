<x-app-layout>
    Hola
</x-app-layout>