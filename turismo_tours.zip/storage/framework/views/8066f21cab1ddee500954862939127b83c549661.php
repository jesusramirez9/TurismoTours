<div class="bg-gray-100">
    <div class="container py-10">
        <h1 class="text-center text-2xl font-bold mb-10 text-gray-700 uppercase tracking-wide">Nuestros viajes</h1>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <div class="shadow-lg   bg-white">
                    <img src="<?php echo e(Storage::url($item->image)); ?>" class="w-full h-64 object-cover object-center" alt="">
                    <h1 class="text-gray-700 pb-2 font-semibold p-3 uppercase"><?php echo e($item->title); ?></h1>
                    <p class="pt-2 text-justify font-medium p-3"><?php echo e($item->content); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <div class="px-6 py-3">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/show-post.blade.php ENDPATH**/ ?>