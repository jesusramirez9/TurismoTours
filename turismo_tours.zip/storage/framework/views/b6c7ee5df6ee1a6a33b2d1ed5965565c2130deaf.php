<div>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 xl:gap-8">
        <div class="text-center btn_filter_rp">
            <button class="bg-green-600 hover:bg-green-700 px-3 py-1 rounded text-white show-modal">
                Filtrar
            </button>
        </div>
        
        <div class="md:col-span-2 lg:col-span-5">
            
            <?php if($view == 'grid'): ?>
                <ul class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3  gap-6">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="bg-white  ">
                            <article class="border-2 overflow-hidden border-gray-300 rounded-xl zoomcatalg ">

                                <a href="<?php echo e(route('products.show', $product)); ?>">
                                    <figure class="relative">
                                        <div class="absolute z-30 mt-4 ml-4">
                                            <?php if($product->offer == 0): ?>
                                            <?php else: ?>
                                                <div class="bg-red-600 text-white px-1 py-1 w-16 rounded-lg z-50">
                                                    <p class="text-center text-sm font-semibold">
                                                        -
                                                        <?php echo e(intval((($product->offer - $product->price) / $product->offer) * 100)); ?>

                                                        %
                                                    </p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($product->images->count()): ?>
                                            <img class=" h-80 w-full object-cover object-center scrollflow -slide-bottom -opacity"
                                                src="<?php echo e(Storage::url($product->images->first()->url)); ?>" alt="">
                                        <?php else: ?>
                                            <img class="h-80 w-full object-cover object-center"
                                                src="https://images.pexels.com/photos/5082560/pexels-photo-5082560.jpeg?cs=srgb&dl=pexels-cottonbro-5082560.jpg&fm=jpg"
                                                alt="">
                                        <?php endif; ?>

                                    </figure>
                                    <div class="py-2 px-2">
                                        <p class="text-gray-400 font-medium text-xs text-center uppercase">
                                            <?php echo e($product->subcategory->name); ?></p>

                                        <h1
                                            class="text-lg  text-center font-semibold scrollflow -slide-bottom -opacity">

                                            <?php echo e(Str::limit($product->name, 40, '...')); ?>


                                        </h1>
                                        <p class="font-bold text-center text-red-600 scrollflow -slide-bottom -opacity">
                                            S/ <?php echo e($product->price); ?></p>
                                        <?php if($product->offer != 0): ?>
                                            <p class="text-center text-gray-300 line-through">s/
                                                <?php echo e($product->offer); ?>

                                            </p>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        <div class="flex justify-center py-4">
                                            <button
                                                class="text-white add_prod font-medium text-sm bg_pricipal px-5 py-2 rounded-xl"><i
                                                    class="fa-solid fa-magnifying-glass mr-2"></i>Ver</button>
                                        </div>


                                    </div>
                                </a>
                            </article>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <li class="md:col-span-2 lg:col-span-4">
                            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative"
                                role="alert">
                                <strong class="font-bold">Upss!</strong>
                                <span class="block sm:inline">No existe ningún producto con ese filtro.</span>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            <?php else: ?>
                <ul>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.product-list','data' => ['product' => $product]]); ?>
<?php $component->withName('product-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative"
                            role="alert">
                            <strong class="font-bold">Upss!</strong>
                            <span class="block sm:inline">No existe ningún producto con ese filtro.</span>
                        </div>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>

            <div class="mt-4 links_mds">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>

    <div
        class="modal h-screen w-full fixed left-0 top-0 flex justify-center items-center bg-black bg-opacity-50 hidden">
        <!-- modal -->
        <div class="bg-white rounded shadow-lg tamaniomodal w-1/2">
            <!-- modal header -->
            <div class="border-b px-4 py-2 flex justify-between items-center">
                <h3 class="font-semibold text-lg">Filtros</h3>
                <button class="text-black close-modal">&cross;</button>
            </div>
            <!-- modal body -->
            <div class="p-3 body_modal">

                <aside class="category_filter_rp">
                    <div id="container-main">
                        <div class="accordion-container">
                            <a class="accordion-titulo open">Categorías<span class="toggle-icon"></span></a>
                            <div class="accordion-content block">
                                <ul class="divide-y divide-gray-200">
                                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <li class="py-2 text-sm rronmaa font-semibold">
                                            <a class="cursor-pointer  hover:text-orange-500 capitalize <?php echo e($subcategoria == $subcategory->slug ? 'text-orange-500  font-semibold' : ''); ?>"
                                                wire:click="$set('subcategoria', '<?php echo e($subcategory->slug); ?>')"><?php echo e($subcategory->name); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="accordion-container">
                            <a class="accordion-titulo open">Precio<span class="toggle-icon"></span></a>
                            <div class="accordion-content block">
                                <ul class="divide-y divide-gray-200">
                                    <?php $__currentLoopData = $precio_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $precioitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="py-2 text-sm rronmaa font-semibold">
                                            <a class="cursor-pointer hover:text-orange-500 capitalize <?php echo e($precioitem == $precioitem['id'] ? 'text-orange-500 font-semibold' : ''); ?> "
                                                wire:click="$set('precio','<?php echo e($precioitem['id']); ?>')"><?php echo e($precioitem['min']); ?>

                                                - <?php echo e($precioitem['max']); ?> </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        
                        
                    </div>
                </aside>
            </div>
            <div class="flex justify-end items-center w-100 border-t p-3">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'mr-6','wire:click' => 'limpiar']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-6','wire:click' => 'limpiar']); ?>
                    Eliminar filtros
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <button
                    class="bg-orange-600 hover:bg-orange-700 px-3 py-1 rounded text-white mr-1 close-modal">Cerrar</button>

            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        const modal = document.querySelector('.modal');

        const showModal = document.querySelector('.show-modal');
        const closeModal = document.querySelectorAll('.close-modal');

        showModal.addEventListener('click', function() {
            modal.classList.remove('hidden')
        });

        closeModal.forEach(close => {
            close.addEventListener('click', function() {
                modal.classList.add('hidden')
            });
        });

        $(".accordion-titulo").click(function() {

            var contenido = $(this).next(".accordion-content");

            if (contenido.css("display") == "none") { //open		
                contenido.slideDown(250);
                $(this).addClass("open");
            } else { //close		
                contenido.slideUp(250);
                $(this).removeClass("open");
            }

        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/category-filter.blade.php ENDPATH**/ ?>