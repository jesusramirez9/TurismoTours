<div>
    <ul class="text-gray-500">
        <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="bg-center bg-cover h-96 w-full object-center" style="background-image: url('<?php echo e($item->options->image); ?>')">
 
        </div>
        
            <li class="flex p-2 border-b border-gray-200">
                
                <article class="flex-1">
                    <h1 class="font-bold my-2"><?php echo e($item->name); ?></h1>
                    <div class="flex">
                        <p class="font-bold">Cantidad: <span class="font-normal"><?php echo e($item->qty); ?> 
                                <?php if($item->qty == 1): ?>
                                    persona
                                <?php else: ?>
                                    personas
                                <?php endif; ?>
                            </span> </p>
                        <?php if(isset($item->options['color'])): ?>
                            <p class="mx-2">- Color: <?php echo e(__($item->options['color'])); ?></p>
                        <?php endif; ?>
                        <?php if(isset($item->options['size'])): ?>
                            <p> - <?php echo e($item->options['size']); ?></p>
                        <?php endif; ?>
                    </div>

                    <p>S/ <?php echo e($item->price); ?></p>
                </article>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="py-6 px-4">
                <p class="text-center text-gray-700">
                    No tiene agregado ninguna reserva
                </p>
            </li>
        <?php endif; ?>
    </ul>
    <?php if(Cart::count()): ?>
        <div class="py-2 px-3">
            <p class="text-lg text-gray-700 mt-2 mb-3"><span class="font-bold">Total: </span> S/
                <?php echo e(Cart::subtotal()); ?> Nuevos soles</p>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button-enlace','data' => ['href' => ''.e(route('shopping-cart')).'','color' => 'orange','class' => 'w-full']]); ?>
<?php $component->withName('button-enlace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('shopping-cart')).'','color' => 'orange','class' => 'w-full']); ?>Procesar Reserva <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <a class="text-sm cursor-pointer hover:underline mt-3 inline-block text-red-600 hover:text-red-800"
                wire:click="destroy">
                <i class="fas fa-trash"></i>
                Borrar la reserva
            </a>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/modal-cart.blade.php ENDPATH**/ ?>