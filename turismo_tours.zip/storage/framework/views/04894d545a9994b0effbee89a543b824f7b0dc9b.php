<div x-data>
    <p class="text-gray-700 mb-4 mt-4"> <span class="text-lg font-semibold">Asientos disponibles:
        </span><?php echo e($quantity); ?></p>
    <div class="flex items-center">
        <?php if($qty == 1): ?>
            <p class="mr-4"><?php echo e($qty); ?> Persona: </p>
        <?php else: ?>
            <p class="mr-4"><?php echo e($qty); ?> Personas: </p>
        <?php endif; ?>
        <div class="mr-4 bordradiu">

            <button class="btn_menmas hover:bg-gray-300 rounded-lg px-4 py-1 bg-gray-100" disabled
                x-bind:disabled="$wire.qty <= 1" wire:loading.attr="disabled" wire:target="decrement"
                wire:click="decrement">
                -
            </button>
            <span class="mx-2 text-gray-700 qtydad"><?php echo e($qty); ?></span>
            <button class="btn_menmas hover:bg-gray-300 rounded-lg px-4 py-1 bg-gray-100"
                x-bind:disabled="$wire.qty >= $wire.quantity" wire:loading.attr="disabled" wire:target="increment"
                wire:click="increment">
                +
            </button>
        </div>
        <div class="flex-1">
            <div class="itemcolbtnweb">
                <button
                    class="text-white add_prod font-medium text-sm bg_pricipal px-5 py-2 rounded-xl hover:bg-blue-700"
                    x-bind:disabled="$wire.qty > $wire.quantity" wire:click="addItem" wire:loading.attr="disabled"
                    wire:target="addItem">Reservar Tour</button>

                
            </div>
            <div class="itemcolorbtn">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['color' => 'orange','xBind:disabled' => '$wire.qty > $wire.quantity','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['color' => 'orange','x-bind:disabled' => '$wire.qty > $wire.quantity','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']); ?>
                    Reservar Tour
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>

        </div>
    </div>
    <div class="mt-8 ">
        <p class="uppercase text-gray-400 font-normal">CODIGO DEL TOUR: <?php echo e($product->code); ?></p>
        

    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'open_edit']]); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'open_edit']); ?>
        <div class="modalPublicidad">
             <?php $__env->slot('title', null, []); ?> 
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('content', null, []); ?> 
                <div class="slide_rlg">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal-cart')->html();
} elseif ($_instance->childHasBeenRendered('l2018552148-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2018552148-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2018552148-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2018552148-0');
} else {
    $response = \Livewire\Livewire::mount('modal-cart');
    $html = $response->html();
    $_instance->logRenderedChild('l2018552148-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

             <?php $__env->endSlot(); ?>
             <?php $__env->slot('footer', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:click' => '$set(\'open_edit\', false)','class' => 'mr-4']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_edit\', false)','class' => 'mr-4']); ?>
                    Continuar viendo
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/add-cart-item.blade.php ENDPATH**/ ?>