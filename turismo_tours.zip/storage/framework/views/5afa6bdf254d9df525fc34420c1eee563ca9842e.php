<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('status-order', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('GIRBdtV')) {
    $componentId = $_instance->getRenderedChildComponentId('GIRBdtV');
    $componentTag = $_instance->getRenderedChildComponentTagName('GIRBdtV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GIRBdtV');
} else {
    $response = \Livewire\Livewire::mount('status-order', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('GIRBdtV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>