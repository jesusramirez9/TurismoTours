<div>
    <?php
        require_once base_path('/vendor/autoload.php');
        
        Lyra\Client::setDefaultUsername('53245831');
        Lyra\Client::setDefaultPassword('testpassword_rMMFIrLkKZi0SGaxj6yHM2Qwk1yXS33epAfDAWiVEY8tE');
        Lyra\Client::setDefaultEndpoint('https://api.micuentaweb.pe');
        Lyra\Client::setDefaultPublicKey('53245831:testpublickey_wxw0RQ0z0huOBb8VoecTvVIMiJbdVLQhtAXmEv3MdNtfC');
        
        Lyra\Client::setDefaultSHA256Key('fBmPcKxYAStyHYWT6qLsKjv0ekto5maeyUEDGkJZtQ8L3');
        $client = new Lyra\Client();
        
        $store = [
            'amount' => $order->total * 100,
            'currency' => 'PEN',
            'orderId' => uniqid('MyOrderId'),
            'customer' => [
                'email' => auth()->user()->email,
            ],
        ];
        $response = $client->post('V4/Charge/CreatePayment', $store);
        
        if ($response['status'] != 'SUCCESS') {
            display_error($response);
            $error = $response['answer'];
            throw new Exception('error ' . $error['errorCode'] . ': ' . $error['errorMessage']);
        }
        
        $formToken = $response['answer']['formToken'];
        
    ?>

    <?php $__env->startPush('link'); ?>
        <link rel="stylesheet" href="<?php echo $client->getClientEndpoint(); ?>/static/js/krypton-client/V4.0/ext/classic-reset.css">
        <script src="<?php echo $client->getClientEndpoint(); ?>/static/js/krypton-client/V4.0/ext/classic.js">
        </script>
    <?php $__env->stopPush(); ?>
    <div class="bg-red-600 py-6">
        <p class="text-center text-white text-lg xl:text-2xl font-semibold">
            Orden de reserva
        </p>
        <div class="text-center">
            <a href="/" class="text-white underline text-sm">Ir al inicio</a>
        </div>
    </div>

    <div class="md:grid  md:grid-cols-5 gap-6 container py-8">

        <div class="md:col-span-3 ">
            <div class="bg-white rounded-lg shadow-lg  md:mt-0 px-4 md:px-6 py-4 mb-6">
                <p class="colorbroywm font-bold uppercase"> <span class=" font-bold">Número de
                        reserva:</span>
                    Reserva-<?php echo e($order->id); ?></p>
            </div>
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-gray-700">
                    <div>
                        <p class="text-lg  font-bold uppercase">Datos de la reserva</p>
                        <?php if($order->envio_type == 1): ?>
                            <p class="text-sm colorbroywm font-bold">Serán recogidos en:</p>
                            <p class="text-sm colorbroywm font-bold">Calle falsa 123</p>
                        <?php else: ?>
                            <p class="text-sm colorbroywm font-bold">Ustes será recogido en:</p>
                           
                            <p class="colorbroywm font-normal"><?php echo e($envio->department); ?> - <?php echo e($envio->city); ?> -
                                <?php echo e($envio->district); ?></p>
                            <p class="text-sm colorbroywm font-bold">Referencia:</p>
                      
                        <?php endif; ?>
                    </div>

                    <div>
                        <p class="text-lg  font-bold uppercase">Datos de contacto principal</p>
                        <p class="text-sm  font-bold">Persona a quien se llamará: </p>
                        <p class="colorbroywm font-normal"> <?php echo e($order->contact); ?></p>
                        <p class="text-sm  font-bold">Celular de contacto: </p>
                        <p class="colorbroywm font-normal"><?php echo e($order->phone); ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-lg p-6 mb-6 text-gray-700">
                <p class="text-xl  font-bold mb-4">Resumen del paquete turístico</p>

                <table class="table-auto w-full">
                    <thead>
                        <tr class=" font-bold">
                            <th></th>
                            <th class="text-xs sm:text-base">Precio</th>
                            <th class="text-xs sm:text-base">Cant/Personas</th>
                            <th class="text-xs sm:text-base">Total</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">

                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="flex ">
                                        <img class="h-15 w-20 object-cover mr-4" src="<?php echo e($item->options->image); ?>"
                                            alt="">
                                        <article>
                                            <h1 class="font-bold txttitel_resumen"><?php echo e($item->name); ?></h1>
                                            <div class="flex text-xs txttitel_resumen">
                                                <?php if(isset($item->options->color)): ?>
                                                    Color: <?php echo e(__($item->options->color)); ?>

                                                <?php endif; ?>

                                                <?php if(isset($item->options->size)): ?>
                                                    - <?php echo e($item->options->size); ?>

                                                <?php endif; ?>
                                            </div>
                                        </article>
                                    </div>
                                </td>
                                <td class="text-center colorbroywm font-bold">
                                    S/ <?php echo e($item->price); ?>

                                </td>
                                <td class="text-center colorbroywm font-bold">
                                    <?php echo e($item->qty); ?>

                                </td>
                                <td class="text-center colorbroywm font-bold">
                                    S/ <?php echo e($item->price * $item->qty); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>



        </div>
        <div class="md:col-span-2">
            <div class="bg-white rounded-lg shadow-lg px-4 md:px-6 pt-6 pb-6">
                <div class="flex justify-between items-center mb-4">
                    <div class="">
                        <img src=" <?php echo e(asset('images/bolsacompra1/visa.jpg')); ?>" class="h-15 w-20 object-cover"
                            alt="">
                        <img src="<?php echo e(asset('images/bolsacompra1/mastercard.jpg')); ?>" class="h-15 w-20 object-cover"
                            alt="">
                    </div>
                    <div class="">
                        <img src="
                        <?php echo e(asset('images/bolsacompra1/american.jpg')); ?>" class="h-15 w-20 object-cover" alt="">
                        <img src="<?php echo e(asset('images/bolsacompra1/diners.jpg')); ?>" class="h-15 w-20 object-cover"
                            alt="">

                    </div>
                    <div class="colorbroywm ml-4">
                        <p class="mb-1  text-sm font-bold ">
                            Subotal: S/ <?php echo e($order->total - $order->shipping_cost); ?>

                        </p>
                        <p class="mb-3  text-sm font-bold ">
                            Envio: S/ <?php echo e($order->shipping_cost); ?>

                        </p>
                        <p class="mb-3 text-lg font-bold uppercase">
                            Total: S/ <?php echo e($order->total); ?>

                        </p>

                        

                    </div>
                </div>

                
                

                

                
                <div class="flex justify-end">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:loading.attr' => 'disabled','wire:target' => 'create_order','class' => 'mt-6 mb-4 ','wire:click' => 'create_order']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:target' => 'create_order','class' => 'mt-6 mb-4 ','wire:click' => 'create_order']); ?>
                        Reservar Tour
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>

            </div>

        </div>

    </div>

    


</div>



<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/payment-order.blade.php ENDPATH**/ ?>