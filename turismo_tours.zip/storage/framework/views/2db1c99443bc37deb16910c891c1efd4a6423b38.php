<div>
    <div class="bg_pricipal py-2 md:py-8">
        <div class=" flex items-center container text-white justify-between">
            <div class="">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.application-mark','data' => ['class' => 'block h-10 md:h-16 w-auto']]); ?>
<?php $component->withName('jet-application-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'block h-10 md:h-16 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <div>
                <div class=" grid grid-cols-1 pb-4 text-xs gap-4 text-center md:flex">
                    <div class="mr-4">
                        <p><i class="far fa-envelope mr-4"></i>ventas@aleckatours.com.pe</p>
                    </div>
                    <div class="mr-4  border-r-2 border-l-2 border-x-white">
                        <p class="px-4"><i class="fab fa-whatsapp mr-4"></i>998 905 385</p>
                    </div>
                    <div class="mr-4">
                        <p><i class="fas fa-map-marker-alt text-white mr-4"></i>Direccion Trepstom</p>
                    </div>
                </div>
                <div class="text-black hidden md:block">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('l2444501842-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2444501842-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2444501842-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2444501842-0');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('l2444501842-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
            <div>
                <div class="flex">
                    <div class="mx-4 hidden md:block">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dropdown-cart')->html();
} elseif ($_instance->childHasBeenRendered('l2444501842-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2444501842-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2444501842-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2444501842-1');
} else {
    $response = \Livewire\Livewire::mount('dropdown-cart');
    $html = $response->html();
    $_instance->logRenderedChild('l2444501842-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="hidden md:block">
                        <?php if(auth()->guard()->check()): ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown','data' => ['align' => 'right','width' => '48']]); ?>
<?php $component->withName('jet-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                                 <?php $__env->slot('trigger', null, []); ?> 

                                    <button
                                        class="flex text-sm border-2 border-transparent rounded-full focus:outline-none focus:border-gray-300 transition">
                                        <img class="h-8 w-8 rounded-full object-cover"
                                            src="<?php echo e(Auth::user()->profile_photo_url); ?>"
                                            alt="<?php echo e(Auth::user()->name); ?>" />
                                    </button>

                                 <?php $__env->endSlot(); ?>

                                 <?php $__env->slot('content', null, []); ?> 
                                    <!-- Account Management -->
                                    <div class="block px-4 py-2 text-xs text-gray-400">
                                        <?php echo e(__('Manage Account')); ?>

                                    </div>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('profile.show')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('profile.show')).'']); ?>
                                        <?php echo e(__('Profile')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('orders.index')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('orders.index')).'']); ?>
                                        Mis ordenes
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('admin.index')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.index')).'']); ?>
                                            Administrador
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php endif; ?>

                                    <div class="border-t border-gray-100"></div>

                                    <!-- Authentication -->
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                                                        this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                                                        this.closest(\'form\').submit();']); ?>
                                            <?php echo e(__('Log Out')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    </form>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown','data' => ['align' => 'right','width' => '48']]); ?>
<?php $component->withName('jet-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>

                                 <?php $__env->slot('trigger', null, []); ?> 
                                    <i class="fas fa-user-circle  text-3xl cursor-pointer"></i>
                                 <?php $__env->endSlot(); ?>

                                 <?php $__env->slot('content', null, []); ?> 
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('login')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('login')).'']); ?>
                                        <?php echo e(__('Login')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('register')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('register')).'']); ?>
                                        <?php echo e(__('Register')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                 <?php $__env->endSlot(); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <header class=" w-full top-0 shadow-xl border-gray-500 border-opacity-20 border-b-2" style="z-index: 900"
        x-data="dropdown()">
        <div class="container flex items-center h-12 justify-center enlace ">
            <a :class="{'bg-opacity-100 text-orange-500' : open}" x-on:click="show()"
                class="flex flex-col items-center justify-center md:hidden order-last md:order-first px-2 md:px-4 bg-white bg-opacity-25  cursor-pointer font-semibold h-2/3">
                <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                    <path class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                
            </a>

            <a href="/"
                class="mx-6  font-normal hover:underline  hidden lg:block  <?php echo e(request()->is('/') ? 'active  ' : ''); ?>">
                Inicio
            </a>
            <a href="<?php echo e(route('conocenos')); ?>"
                class="mx-6  font-normal  hover:underline  hidden lg:block  <?php echo e(request()->is('conocenos') ? 'active     ' : ''); ?>">
                Conócenos
            </a>
            <a href="http://127.0.0.1:8000/categories/tours"
                class="mx-6  font-normal hover:underline   hidden md:block  <?php echo e(request()->is('categories/*') ? 'active  ' : ''); ?>">
                Tours
            </a>
            <a href="<?php echo e(route('servicios')); ?>"
                class="mx-6  font-normal  hover:underline  hidden md:block  <?php echo e(request()->is('servicios') ? 'active  ' : ''); ?>">
                Servicios
            </a>
            <a href="<?php echo e(route('noticia.show')); ?>"
                class="mx-6  font-normal  hover:underline  hidden md:block  <?php echo e(request()->is('noticia') ? 'active ' : ''); ?>">
                Galeria
            </a>
            <a href="<?php echo e(route('ventamayor')); ?>"
                class="mx-6  font-normal  hover:underline  hidden md:block  <?php echo e(request()->is('ventas-al-por-mayor') ? 'active ' : ''); ?>">
                Tour Privado
            </a>
            <a href="<?php echo e(route('contacto')); ?>"
                class="mx-6  font-normal  hover:underline  hidden md:block  <?php echo e(request()->is('contactanos') ? 'active ' : ''); ?>">
                Escríbenos
            </a>

            <a href="#" class="md:mx-6">
                <i class="fa-brands fa-facebook-square fa-2x"></i></a>
            <a href="#" class=""><img class="w-9 h-9"
                    src="<?php echo e(asset('img/iconos/insta.png')); ?>" alt=""></a>

        </div>

        <nav id="navigation-menu" :class="{'block': open, 'hidden': !open}"
            class="bg-trueGray-700 mt-4 z-10 bg-opacity-25 w-full absolute hidden">

            
            

            
            <div class="bg-white h-2/5 overflow-y-auto">

                <div class="container bg-gray-200 py-3 mb-2">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('l2444501842-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l2444501842-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2444501842-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2444501842-2');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('l2444501842-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <li>
                        <a href="<?php echo e(route('conocenos')); ?>"
                            class="py-2 px-4 text-sm flex items-center <?php echo e(request()->is('conocenos') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <?php echo $category->icon; ?>

                            </span>
                            Conócenos
                        </a>
                    </li>
                    <li>
                        <a href="http://127.0.0.1:8000/categories/tours"
                            class="py-2 px-4 text-sm flex items-center <?php echo e(request()->is('categories/*') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <?php echo $category->icon; ?>

                            </span>
                            Catálogo
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('servicios')); ?>"
                            class="py-2 px-4 text-sm flex items-center <?php echo e(request()->is('servicios') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <?php echo $category->icon; ?>

                            </span>
                            Servicios
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contacto')); ?>" class="py-2 px-4 text-sm flex items-center">
                            <span class="flex justify-center w-9">
                                <?php echo $category->icon; ?>

                            </span>
                            Escríbenos
                        </a>
                    </li>

                </ul>
                
            </div>
        </nav>
    </header>
    
    <?php $__env->startPush('script'); ?>
       
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/navigation.blade.php ENDPATH**/ ?>