<footer class="border-2 border-gray-400 border-opacity-20 border-t-2 mt-14 pt-6">
  
    <div class="max-w-8xl mx-auto px-2  grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-16">
        <div>
            <div class="mb-6">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.application-mark','data' => ['class' => 'block h-10 md:h-16 w-auto']]); ?>
<?php $component->withName('jet-application-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'block h-10 md:h-16 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <div class="flex  mb-6">
                <div>
                    <p class="font-bold">SÍGUENOS EN</p>
                </div>
                <div class="mx-4">
                    <i class="fa-brands fa-facebook-f"></i>
                </div>
                <div class="">
                    <i class="fa-brands fa-instagram"></i>
                </div>
            </div>
            <div class="grid grid-cols-3 lg:grid-cols-4  gap-3">
                <div>
                    <img src="<?php echo e(asset('img/iconos/mastercard.jpg')); ?>" alt="">
                </div>
                <div>
                    <img src="<?php echo e(asset('img/iconos/exprexx.jpg')); ?>" alt="">
                </div>
                <div>
                    <img src="<?php echo e(asset('img/iconos/visa.jpg')); ?>" alt="">
                </div>
                <div>
                    <img src="<?php echo e(asset('img/iconos/pagoefectivo.png')); ?>" alt="">
                </div>
                <div>
                    <img src="<?php echo e(asset('img/iconos/mercadopago.png')); ?>" alt="">
                </div>
                <div>
                    <img src="<?php echo e(asset('img/iconos/paypal.jpg')); ?>" alt="">
                </div>
                <div>
                    <img src="<?php echo e(asset('img/iconos/scotiabank.png')); ?>" alt="">
                </div>
                
            </div>
        </div>
        <div>
            <p class="text-base font-bold mb-3">CONTACTO</p>
            <ul class="text-sm ulli ulcontact">
                <li><i class="fas fa-map-marker-alt mr-2"></i>Av. Canada 3770 - San Luis</li>
                <li><i class="fas fa-phone color-icon-footer mr-2"></i> (01) 436 6643</li>
                <li><i class="fas fa-mobile-alt color-icon-footer mr-2"></i> 989 056 593 </li>
                <li><i class="fab fa-whatsapp color-icon-footer mr-2"></i>914 673 518</li>
                <li><i class="far fa-envelope color-icon-footer mr-2"></i>ventas@aleckatravelstours.com.pe</li>
            </ul>
        </div>
        <div>
            <p class="text-base font-bold mb-3">POLITICAS</p>
            <ul class="text-sm ulli">
                <li><a href="<?php echo e(route('politicas')); ?>">Políticas de privacidad</a> </li>
                <li><a href="<?php echo e(route('terminos')); ?>"> Términos y condiciones</a></li>
                <li>Preguntas Frecuentes</li>
                <li>Libro de reclamaciones</li>
            </ul>
        </div>
        <div>
            <p class="text-base font-bold mb-3">INFORME</p>
            <ul class="text-sm ulli">
                <li>Factura electrónica</li>
                <li>Términos y condiciones</li>
                <li>Proveedor B to B</li>
                <li>Proveedor B to C</li>
            </ul>
        </div>
        <div>
            <p class="text-base font-bold mb-3">VENTA CORPORATIVA</p>
            <ul class="text-sm ulli">
                <li><i class="fas fa-phone color-icon-footer mr-2"></i> (01) 436 6643</li>
                <li><i class="fas fa-mobile-alt color-icon-footer mr-2"></i> 989 056 593 </li>
                <li><i class="far fa-envelope color-icon-footer mr-2"></i>ventas@aleckatravelstours.com.pe</li>
                <li><i class="fas fa-map-marker-alt mr-2"></i>Av. Canada 3770 - San Luis</li>

            </ul>
        </div>
    </div>
    
    <div class="bg-gray-700  text-white py-2 mt-8">
        <div class="flex justify-center">
            <p>Copyright © 2022 | <span class="font-serif font-semibold"> Consultora Trepstom </span></p>
        </div>
    </div>
    
</footer><?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/footer.blade.php ENDPATH**/ ?>