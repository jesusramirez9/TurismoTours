<div>
    
    <div class="max-w-5xl  mx-auto px-4 sm:px-6 lg:px-8 py-12 ">

        <div class="bg-white rounded-lg shadow-lg px-12 py-8 mb-6 flex items-center">

            <div class="relative">
                <div class="<?php echo e(($order->status >=2 && $order->statud != 5) ? 'bg-blue-400 ' : 'bg-gray-400 '); ?> rounded-full h-12 w-12 flex items-center justify-center ">
                    <i class="fas fa-check text-white"></i>
                </div>
                <div class="absolute -left-1.5 mt-0.5">
                    <p >Recibido</p>
                </div>
            </div>

            <div class="<?php echo e(($order->status >=3 && $order->statud != 5) ? 'bg-blue-400 ' : 'bg-gray-400 '); ?>h-1 flex-1 mx-2"></div>

            <div class="relative">
                <div class="<?php echo e(($order->status >=3 && $order->statud != 5) ? 'bg-blue-400 ' : 'bg-gray-400 '); ?> rounded-full h-12 w-12 flex items-center justify-center ">
                    <i class="fas fa-truck text-white"></i>
                </div>
                <div class="absolute -left-1 mt-0.5">
                    <p >Enviado</p>
                </div>
            </div>

            <div class="<?php echo e(($order->status >=4 && $order->statud != 5) ? 'bg-blue-400 ' : 'bg-gray-400 '); ?> h-1 flex-1  mx-2"></div>

            <div class="relative">
                <div class="<?php echo e(($order->status >=4 && $order->statud != 5) ? 'bg-blue-400 ' : 'bg-gray-400 '); ?> rounded-full h-12 w-12 flex items-center justify-center ">
                    <i class="fas fa-check text-white"></i>
                </div>
                <div class="absolute -left-1 mt-0.5">
                    <p >Entregado</p>
                </div>
            </div>




        </div>
        <div class="bg-white rounded-lg shadow-lg px-6 py-4 mb-6">
            <p class="text-gray-700 uppercase"> <span class="font-semibold">Número de orden:</span>
                Orden-<?php echo e($order->id); ?></p>
            <form wire:submit.prevent="update">
                <div class="flex space-x-3 mt-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => []]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <input wire:model="status" type="radio" name="status" value="2" class="mr-2" />
                        RECIBIDO
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => []]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <input wire:model="status" type="radio" name="status" value="3" class="mr-2" />
                        PROCESADO
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => []]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <input wire:model="status" type="radio" name="status" value="4" class="mr-2" />
                        RESERVADO
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => []]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        <input wire:model="status" type="radio" name="status" value="5" class="mr-2" />
                        ANULADO
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>

                <div class="flex mt-2">

                   
                    <div class="ml-auto">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.action-message','data' => ['class' => 'mr-3 ','on' => 'saved']]); ?>
<?php $component->withName('jet-action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-3 ','on' => 'saved']); ?>
                            Actualizado
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => []]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            Actualizar
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    
                </div>
            </form>
        </div>
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <div class="grid grid-cols-2 gap-6 text-gray-700">
                <div>
                    <p class="text-lg font-semibold uppercase">Envío</p>
                    <?php if($order->envio_type == 1): ?>
                        <p class="text-sm">Los productos deben ser recogidos en tienda</p>
                        <p class="text-sm">Calle falsa 123</p>
                    <?php else: ?>
                        <p class="text-sm">El cliente será recogido en:</p>
                      
                        <p><?php echo e($envio->department); ?> - <?php echo e($envio->city); ?> -
                            <?php echo e($envio->district); ?></p>
                    <?php endif; ?>
                </div>

                <div>
                    <p class="text-lg font-semibold uppercase">Datos de contacto</p>
                    <p class="text-sm">Persona quien recibirá el servicio: <?php echo e($order->contact); ?></p>
                    <p class="text-sm">Teléfono de contacto <?php echo e($order->phone); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-lg p-6 mb-6 text-gray-700">
            <p class="text-xl font-semibold mb-4">Resumen</p>

            <table class="table-auto w-full">
                <thead>
                    <tr>
                        <th></th>
                        <th>Precio</th>
                        <th>Canti</th>
                        <th>total</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">

                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="flex ">
                                    <img class="h-15 w-20 object-cover mr-4" src="<?php echo e($item->options->image); ?>" alt="">
                                    <article>
                                        <h1 class="font-bold"><?php echo e($item->name); ?></h1>
                                        <div class="flex text-xs">
                                            <?php if(isset($item->options->color)): ?>
                                                Color: <?php echo e(__($item->options->color)); ?>

                                            <?php endif; ?>

                                            <?php if(isset($item->options->size)): ?>
                                                - <?php echo e($item->options->size); ?>

                                            <?php endif; ?>
                                        </div>
                                    </article>
                                </div>
                            </td>
                            <td class="text-center">
                                S/ <?php echo e($item->price); ?> 
                            </td>
                            <td class="text-center">
                                <?php echo e($item->qty); ?>

                            </td>
                            <td class="text-center">
                                S/ <?php echo e($item->price * $item->qty); ?> 
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>

    </div>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/status-order.blade.php ENDPATH**/ ?>