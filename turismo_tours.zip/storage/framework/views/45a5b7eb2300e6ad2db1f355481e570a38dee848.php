<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container my-10 xl:my-20">
        <div class="grid grid-cols-1 md:grid-cols-2 items-center gap-8 ">

            <div>
                <div>
                    <div class="flex justify-center">
                        <img src="<?php echo e(asset('img/contacto/flota2.png')); ?>" class="w-3/4" alt="">
                    </div>
                    <h1 class="text-center my-4 text-2xl text-blue-800  font-bold ">
                        SOMOS UNA AGENCIA DE CONFIANZA
                    </h1>
                    <p class="text-justify">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur, repudiandae nobis quos repellendus veritatis harum placeat voluptatum architecto quia vel consequatur velit saepe. Accusantium dignissimos error nesciunt sequi, neque fugit!
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odit veritatis dolorum odio dolorem officia et autem! Sequi fuga voluptatum molestias qui, quo iusto, itaque adipisci nesciunt illo enim facilis a. Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione sapiente magnam amet? Incidunt quos necessitatibus tempore sequi asperiores cum dolorem quisquam, dignissimos eos illo iusto reprehenderit et harum nesciunt cupiditate.
                    </p>
                    <p class="text-center mt-4 text-2xl text-blue-800 hover:text-blue-400 font-bold cursor-pointer">
                        <i class="fas fa-mobile-alt mr-2"></i> 998 905 385
                    </p>
                </div>
            </div>
            <div class="">
                <p class="my-4 text-2xl font-bold uppercase text-center">Contáctanos:</p>
                <form action="<?php echo e(route('contacto.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="grid grid-cols-1 gap-5  mt-5">
                        <input name="name"
                            class="w-full bg-gray-50 text-gray-900 mt-2 p-3 brdinput focus:outline-none focus:shadow-outline"
                            type="text" placeholder="Nombres*" />
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><strong><?php echo e($message); ?></strong></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input name="Apellidos"
                            class="w-full bg-gray-50 text-gray-900 mt-2 p-3 brdinput focus:outline-none focus:shadow-outline"
                            type="text" placeholder="Apellidos*" />
                        <?php $__errorArgs = ['Apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><strong><?php echo e($message); ?></strong></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input name="correo"
                            class="w-full bg-gray-50 text-gray-900 mt-2 p-3 brdinput focus:outline-none focus:shadow-outline"
                            type="email" placeholder="Correo electrónico*" />
                        <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><strong><?php echo e($message); ?></strong></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input name="celular"
                            class="w-full bg-gray-50 text-gray-900 mt-2 p-3 brdinput focus:outline-none focus:shadow-outline"
                            type="number" placeholder="Teléfono*" />
                        <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><strong><?php echo e($message); ?></strong></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="my-4">
                        <textarea name="mensaje" placeholder="Mensaje*"
                            class="w-full h-32 bg-gray-50 text-gray-900 mt-2 p-3 brdinput focus:outline-none focus:shadow-outline"></textarea>
                        <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><strong><?php echo e($message); ?></strong></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="my-2  text-right">
                        <button type="submit"
                            class="font-bold tracking-wide bg-gray-700 hover:bg-gray-600 text-gray-50 rounded-lg px-4 py-2   
                          focus:outline-none focus:shadow-outline">
                            Enviar
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

  

    <?php if(session('info')): ?>
        <script>
            alert("<?php echo e(session('info')); ?>")
        </script>
    <?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/web/ventasmayor.blade.php ENDPATH**/ ?>