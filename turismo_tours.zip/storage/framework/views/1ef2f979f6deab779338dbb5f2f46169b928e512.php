<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
    <div class="container  pt-6 md:pt-14 pb-14">
        

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category-filter', ['category' => $category])->html();
} elseif ($_instance->childHasBeenRendered('8SUilyD')) {
    $componentId = $_instance->getRenderedChildComponentId('8SUilyD');
    $componentTag = $_instance->getRenderedChildComponentTagName('8SUilyD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8SUilyD');
} else {
    $response = \Livewire\Livewire::mount('category-filter', ['category' => $category]);
    $html = $response->html();
    $_instance->logRenderedChild('8SUilyD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/categories/show.blade.php ENDPATH**/ ?>