<div>
    <div class="card">
        <div class="card-body shadow-xl px-4 py-4">
            <h4 class="my-6 font-medium text-purple-700 text-lg">Valoraciones</h4>
            <?php if(auth()->guard()->check()): ?>
                <div>
                    <article>
                        <textarea wire:model="comment" placeholder="Ingrese una reseña del producto"
                            class="border-gray-400 border-opacity-20 border-2" name="" id="" cols="30" rows="4"></textarea>
                        <div class="flex items-center">
                            <button wire:click="store"
                                class="bg-green-800 py-3 px-4 mt-2 text-white rounded-xl mr-3">Comentar</button>

                            <div>
                                <ul class="flex ">
                                    <li class="mr-1 cursor-pointer" wire:click="$set('rating', 1)">
                                        <i
                                            class="fas fa-star text-<?php echo e($rating >= 1 ? 'yellow' : 'gray'); ?>-400 hover:text-yellow-400"></i>
                                    </li>
                                    <li class="mr-1 cursor-pointer" wire:click="$set('rating', 2)">
                                        <i
                                            class="fas fa-star text-<?php echo e($rating >= 2 ? 'yellow' : 'gray'); ?>-400 hover:text-yellow-400"></i>
                                    </li>
                                    <li class="mr-1 cursor-pointer" wire:click="$set('rating', 3)">
                                        <i
                                            class="fas fa-star text-<?php echo e($rating >= 3 ? 'yellow' : 'gray'); ?>-400 hover:text-yellow-400"></i>
                                    </li>
                                    <li class="mr-1 cursor-pointer" wire:click="$set('rating', 4)">
                                        <i
                                            class="fas fa-star text-<?php echo e($rating >= 4 ? 'yellow' : 'gray'); ?>-400 hover:text-yellow-400"></i>
                                    </li>
                                    <li class="mr-1 cursor-pointer" wire:click="$set('rating', 5)">
                                        <i
                                            class="fas fa-star text-<?php echo e($rating >= 5 ? 'yellow' : 'gray'); ?>-400 hover:text-yellow-400"></i>
                                    </li>
                                </ul>

                            </div>
                            <div>
                                <?php switch($rating):
                                    case (1): ?>
                                        <p>Servicio malo</p>
                                    <?php break; ?>
                                    <?php case (2): ?>
                                        <p>Servicio no tan malo</p>
                                    <?php break; ?>
                                    <?php case (3): ?>
                                        <p>Servicio común</p>
                                    <?php break; ?>
                                    <?php case (4): ?>
                                        <p>Servicio bueno</p>
                                    <?php break; ?>
                                    <?php case (5): ?>
                                        <p>Servicio excelente</p>
                                    <?php break; ?>
                                    <?php default: ?>

                                <?php endswitch; ?>
                            </div>
                        </div>

                    </article>
                </div>
                <?php else: ?>

            <p class="text-gray-800 mt-8 mb-4"> Para comentar y dar valoración a algunos de nuestros servicios, deberás registrarte a nuestra plataforma</p>
            <a href="<?php echo e(route('register')); ?>" class="bg-red-400 text-white font-bold py-2 px-2 rounded-lg">Regístrate aqui</a>


            <?php endif; ?>
            <p class="text-gray-800 mt-8 mb-4"><?php echo e($product->reviews->count()); ?> Valoraciones</p>
            <div class="contenspace overflow-auto">
               
                <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="flex mb-4 text-gray-800">
                        <figure class="mr-4">
                            <img class="h-12 w-12 object-cover rounded-full shadow-lg"
                                src="<?php echo e($review->user->profile_photo_url); ?>" alt="">
                        </figure>

                        <div class="card flex-1">
                            <div class="card-body bg-gray-100 py-2 px-4">
                                <p><b><?php echo e($review->user->name); ?></b> <i class="fas fa-star text-yellow-400"></i>
                                    (<?php echo e($review->rating); ?>) </p>
                                    <p class="text-sm"><?php echo e($review->created_at->diffForHumans()); ?></p>
                                <?php switch( $review->rating ):
                                    case (1): ?>
                                        <p class="text-blue-700 font-medium py-2">Servicio malo</p>
                                    <?php break; ?>
                                    <?php case (2): ?>
                                        <p class="text-blue-700 font-medium py-2">Servicio no tan malo</p>
                                    <?php break; ?>
                                    <?php case (3): ?>
                                        <p class="text-blue-700 font-medium py-2">Servicio común</p>
                                    <?php break; ?>
                                    <?php case (4): ?>
                                        <p class="text-blue-700 font-medium py-2">Servicio bueno</p>
                                    <?php break; ?>
                                    <?php case (5): ?>
                                        <p class="text-blue-700 font-medium py-2">Servicio excelente</p>
                                    <?php break; ?>
                                    <?php default: ?>

                                <?php endswitch; ?>
                                <?php echo e($review->comment); ?>

                                
                            </div>
                            
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/products-reviews.blade.php ENDPATH**/ ?>