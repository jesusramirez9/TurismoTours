<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <div class="container  py-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-24">
            <div>
                <!-- Place somewhere in the <body> of your page -->
                
                <div class="flexslider">
                    <ul class="slides">

                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="" data-thumb="<?php echo e(Storage::url($image->url)); ?>">
                                <img class="" src="<?php echo e(Storage::url($image->url)); ?>" />
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            </div>
            <div class="-mt-8 md:mt-12">
                <p class="text-base mb-4">Calificación: <?php echo e(round($product->reviews->avg('rating'), 1)); ?> <i
                        class="fas fa-star text-yellow-400 "></i></p>
                <p class="mb-4 uppercase"> <i class="fas fa-arrow-right mr-4"></i> <span class="">
                        <?php echo e($product->subcategory->name); ?></span> </p>

                <h1 class=" font-bold text-3xl"> <?php echo e($product->name); ?></h1>
                <div class="flex mt-4">

                    <a class="underline hover:text-orange-600" href="#resña"><?php echo e(count($product->reviews)); ?>

                        comentarios
                        de nuestros clientes</a>
                </div>
                <div class="flex items-center">
                    <p class="text-2xl my-4 font-semibold "><span class="text-xs">S/</span>
                        <?php echo e($product->price); ?></p>
                    <div class="mx-4">
                        <?php if($product->offer != 0): ?>
                            <p class=" text-gray-300 line-through">S/ <?php echo e($product->offer); ?></p>
                        <?php else: ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-justify normal-case mb-4">
                    <p><?php echo $product->description; ?></p>
                </div>
                

                <?php if($product->subcategory->size): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item-size', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('nQCE1FG')) {
    $componentId = $_instance->getRenderedChildComponentId('nQCE1FG');
    $componentTag = $_instance->getRenderedChildComponentTagName('nQCE1FG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nQCE1FG');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item-size', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('nQCE1FG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php elseif($product->subcategory->color): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item-color', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('UNKnwh9')) {
    $componentId = $_instance->getRenderedChildComponentId('UNKnwh9');
    $componentTag = $_instance->getRenderedChildComponentTagName('UNKnwh9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UNKnwh9');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item-color', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('UNKnwh9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php else: ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('Mr5U2LN')) {
    $componentId = $_instance->getRenderedChildComponentId('Mr5U2LN');
    $componentTag = $_instance->getRenderedChildComponentTagName('Mr5U2LN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Mr5U2LN');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('Mr5U2LN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endif; ?>
            </div>
        </div>
        <div class="container mt-10">
            <p>
                <?php echo $product->specification; ?>

            </p>
        </div>

        


        <div class="text-center">
            <div class="text-center py-4 md:py-8 lg:py-14">
                <p class="text-xl md:text-2xl ">Más tours encontrados en Alecka Tours <span
                        class="text-black font-semibold text-xl lg:text-2xl"><?php echo e($product->subcategory->name); ?></span>
                </p>
            </div>

            <div class="glider-contain">
                <div class="prelacionado">
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $subcategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mx-4 border-2 overflow-hidden border-gray-300 rounded-xl">
                                <figure>

                                    <?php if($product->images->count()): ?>
                                        <img class="h-80 w-full object-cover object-center scrollflow -slide-bottom -opacity"
                                            src="<?php echo e(Storage::url($product->images->first()->url)); ?>" alt="">
                                    <?php else: ?>
                                        <img class="h-80 w-full object-cover object-center"
                                            src="https://images.pexels.com/photos/5082560/pexels-photo-5082560.jpeg?cs=srgb&dl=pexels-cottonbro-5082560.jpg&fm=jpg"
                                            alt="">
                                    <?php endif; ?>

                                </figure>
                                <a href="<?php echo e(route('products.show', $product)); ?>">
                                   
                                    <div class="py-2 px-2">
                                        <p class="text-gray-400 font-medium text-xs text-center uppercase">
                                            <?php echo e($product->subcategory->name); ?></p>

                                        <h1
                                            class="text-lg  text-center font-semibold scrollflow -slide-bottom -opacity">

                                            <?php echo e(Str::limit($product->name, 40, '...')); ?>


                                        </h1>
                                        <p class="font-bold text-center text-red-600 scrollflow -slide-bottom -opacity">
                                            S/ <?php echo e($product->price); ?></p>
                                        <?php if($product->offer != 0): ?>
                                            <p class="text-center text-gray-300 line-through">s/ <?php echo e($product->offer); ?>

                                            </p>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        <div class="flex justify-center py-4">
                                            <button
                                                class="text-white add_prod font-medium text-sm bg_pricipal px-5 py-2 rounded-xl"><i
                                                class="fa-solid fa-magnifying-glass mr-2"></i>Ver</button>
                                        </div>


                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button aria-label="Previous" class="glider-prev glid-img1"></button>
                <button aria-label="Next" class="glider-next glid-img2"></button>

            </div>

        </div>
        

        <div>
            <a name="resña"></a>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('products-reviews', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('vl2HqJI')) {
    $componentId = $_instance->getRenderedChildComponentId('vl2HqJI');
    $componentTag = $_instance->getRenderedChildComponentTagName('vl2HqJI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vl2HqJI');
} else {
    $response = \Livewire\Livewire::mount('products-reviews', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('vl2HqJI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>
    <?php $__env->startPush('script'); ?>
        <script>
            // Can also be used with $(document).ready()
            $(document).ready(function() {
                $('.flexslider').flexslider({
                    animation: "slide",
                    controlNav: "thumbnails"
                });
            });

            new Glider(document.querySelector('.prelacionado'), {
                slidesToShow: 3,
                slidesToScroll: 1,
                draggable: true,
                dots: '.dots',
                arrows: {
                    prev: '.glider-prev',
                    next: '.glider-next'
                },
                responsive: [{
                        // screens greater than >= 775px
                        breakpoint: 768,
                        settings: {
                            // Set to `auto` and provide item width to adjust to viewport
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            itemWidth: 150,
                            duration: 1.5
                        }
                    },

                    {
                        // screens greater than >= 1024px
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1,
                            itemWidth: 150,
                            duration: 1.5,
                            arrows: {
                                prev: '.glider-prev',
                                next: '.glider-next'
                            },

                        }
                    },
                    {
                        // screens greater than >= 1024px
                        breakpoint: 1250,
                        settings: {
                            slidesToShow: 4,
                            slidesToScroll: 1,
                            itemWidth: 150,
                            duration: 1.5,
                            arrows: {
                                prev: '.glider-prev',
                                next: '.glider-next'
                            },

                        }
                    },
                    {
                        // screens greater than >= 1024px
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            itemWidth: 150,
                            duration: 0.25,
                            arrows: false
                        }
                    },
                    {
                        // screens greater than >= 1024px
                        breakpoint: 320,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            itemWidth: 150,
                            duration: 0.25,
                            arrows: false
                        }
                    }

                ]
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/products/show.blade.php ENDPATH**/ ?>