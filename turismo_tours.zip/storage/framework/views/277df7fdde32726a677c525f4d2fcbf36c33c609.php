<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-5xl  mx-auto px-4 sm:px-6 lg:px-8  md:pt-12 pb-12 py-12">

        <div class="bg-white rounded-lg shadow-lg px-6 md:px-12 py-8 mb-6 flex items-center">

            <div class="relative">
                <div
                    class="<?php echo e($order->status >= 2 && $order->statud != 5 ? 'bg-green-700 ' : 'bg-gray-400 '); ?> rounded-full h-12 w-12 flex items-center justify-center ">
                    <i class="fas fa-check text-white"></i>
                </div>
                <div class="absolute -left-1.5 mt-0.5">
                    <p class="text-sm">Recibido</p>
                </div>
            </div>

            <div
                class="<?php echo e($order->status >= 3 && $order->statud != 5 ? 'bg-green-700 ' : 'bg-gray-400 '); ?>h-1 flex-1 mx-2">
            </div>

            <div class="relative">
                <div
                    class="<?php echo e($order->status >= 3 && $order->statud != 5 ? 'bg-green-700 ' : 'bg-gray-400 '); ?> rounded-full h-12 w-12 flex items-center justify-center ">
                    <i class="fas fa-truck text-white"></i>
                </div>
                <div class="absolute -left-1 mt-0.5">
                    <p class="text-sm md:text-base">Procesando</p>
                </div>
            </div>

            <div
                class="<?php echo e($order->status >= 4 && $order->statud != 5 ? 'bg-blue-400 ' : 'bg-gray-400 '); ?> h-1 flex-1  mx-2">
            </div>

            <div class="relative">
                <div
                    class="<?php echo e($order->status >= 4 && $order->statud != 5 ? 'bg-blue-400 ' : 'bg-gray-400 '); ?> rounded-full h-12 w-12 flex items-center justify-center ">
                    <i class="fas fa-check text-white"></i>
                </div>
                <div class="absolute -left-1 mt-0.5">
                    <p class="text-sm md:text-base">Reservado</p>
                </div>
            </div>


            <div class="<?php echo e($order->status == 5 ? 'bg-red-400 block' : 'bg-gray-400 hidden'); ?> h-1 flex-1  mx-2">
            </div>
            <div class="relative">
                <div
                    class="<?php echo e($order->status == 5 ? 'bg-red-400 block' : 'bg-gray-400 hidden'); ?> rounded-full h-12 w-12 flex items-center justify-center ">
                    <i class="fas fa-window-close text-white "></i>
                </div>
                <div class="<?php echo e($order->status == 5 ? ' block' : 'hidden'); ?> absolute -left-1 mt-0.5">
                    <p class="text-sm md:text-base">Anulado</p>
                </div>
            </div>



        </div>

        <div class="bg-blue-50 rounded-lg shadow-lg px-6 py-4 mb-6 items-center">


            <p>
                <span class="text-gray-600 font-bold">Estado: </span>
                Recibido
            </p>
            <p>En este estado el servicio ya se encuentra registrado en nuestras instalaciones.</p>
            <p>
                <span class="text-gray-600 font-bold">Estado: </span>
                Procesando
            </p>
            <p>En este estado el servicio ya se encuentra en proceso para la reserva.</p>

            <p>
                <span class="text-gray-600 font-bold">Estado: </span>
                Entregado
            </p>
            <p>Muchas gracias por tu compra</p>




        </div>

        <div class="bg-white rounded-lg shadow-lg px-6 py-4 mb-6 flex items-center">
            <p class="colorbroywm font-bold uppercase"> <span class=" font-bold">Número de reserva:</span>
                Reserva-<?php echo e($order->id); ?></p>
            <?php if($order->status == 1): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button-enlace','data' => ['class' => ' bg-red-400 ml-auto cursor-pointer','href' => ''.e(route('orders.payment', $order)).'']]); ?>
<?php $component->withName('button-enlace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => ' bg-red-400 ml-auto cursor-pointer','href' => ''.e(route('orders.payment', $order)).'']); ?>Ir a pagar <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-gray-700">
                <div>
                    <p class="text-lg  font-bold uppercase">Envío</p>
                    <?php if($order->envio_type == 1): ?>
                        <p class="text-sm colorbroywm font-semibold">Usted será recogido en la siguiente dirección:</p>
                        <p class="text-sm colorbroywm ">Calle falsa 123</p>
                    <?php else: ?>
                        <p class="text-sm colorbroywm font-semibold">Usted será recogido en la siguiente dirección:</p>
                     
                        <p class="colorbroywm "><?php echo e($envio->department); ?> - <?php echo e($envio->city); ?> -
                            <?php echo e($envio->district); ?></p>
                        
                    <?php endif; ?>
                </div>

                <div>
                    <p class="text-lg  font-bold uppercase">Datos de contacto</p>
                    <p class="text-sm  font-semibold">Persona quien reservó el tour: </p>
                    <p class="colorbroywm"><?php echo e($order->contact); ?></p>
                    <p class="text-sm  font-semibold">Celular de contacto:</p>
                    <p class="colorbroywm"> <?php echo e($order->phone); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-lg p-6 mb-6 text-gray-700">
            <p class="text-xl mb-4  font-bold">Resumen</p>

            <table class="table-auto w-full">
                <thead>
                    <tr class=" font-bold">
                        <th></th>
                        <th class="text-xs sm:text-base">Precio</th>
                        <th class="text-xs sm:text-base">Canti/personas</th>
                        <th class="text-xs sm:text-base">total</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">

                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="flex ">

                                    <img class="h-15 w-20 object-cover mr-4" src="<?php echo e($item->options->image); ?>"
                                        alt="">



                                    <article>
                                        <h1 class="font-bold txttitel_resumen"><?php echo e($item->name); ?></h1>
                                        <div class="flex text-xs txttitel_resumen">
                                            <?php if(isset($item->options->color)): ?>
                                                Color: <?php echo e(__($item->options->color)); ?>

                                            <?php endif; ?>

                                            <?php if(isset($item->options->size)): ?>
                                                - <?php echo e($item->options->size); ?>

                                            <?php endif; ?>
                                        </div>
                                    </article>
                                </div>
                            </td>
                            <td class="text-center colorbroywm font-bold text-xs sm:text-base">
                                S/<?php echo e($item->price); ?>

                            </td>
                            <td class="text-center colorbroywm font-bold text-xs sm:text-base">
                                <?php echo e($item->qty); ?> personas
                            </td>
                            <td class="text-center colorbroywm font-bold text-xs sm:text-base">
                                S/<?php echo e($item->price * $item->qty); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/orders/show.blade.php ENDPATH**/ ?>