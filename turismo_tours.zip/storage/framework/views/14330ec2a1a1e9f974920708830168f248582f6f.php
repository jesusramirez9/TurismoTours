<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-12">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.create-category')->html();
} elseif ($_instance->childHasBeenRendered('u0mUqFa')) {
    $componentId = $_instance->getRenderedChildComponentId('u0mUqFa');
    $componentTag = $_instance->getRenderedChildComponentTagName('u0mUqFa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('u0mUqFa');
} else {
    $response = \Livewire\Livewire::mount('admin.create-category');
    $html = $response->html();
    $_instance->logRenderedChild('u0mUqFa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <?php $__env->startPush('script'); ?>

    <script>
        livewire.on('deleteCategory', categorySlug =>{
            Swal.fire({
                    title: '¿Estas seguro?',
                    text: "¡No podrás revertir esto!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Sí, bórralo!'

                }).then((result) => {
                    if (result.isConfirmed) {

                          Livewire.emitTo('admin.create-category', 'delete', categorySlug);

                        Swal.fire(  
                            'Eliminado!',
                            'Tu archivo ha sido eliminado.',
                            'éxito'
                        )
                    }
                })
        })
    </script>
        
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>