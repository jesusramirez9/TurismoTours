<div>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-12">
        <!-- This example requires Tailwind CSS v2.0+ -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table','data' => []]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <div class="px-6 py-4 flex items-center">
                
                <div class="flex items-center">
                    <span class="mr-3">Mostrar</span>
                    <select class="mx-5 form-control" wire:model="cant">
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span class="ml-3">entradas</span>
                </div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'flex-1 mx-4','placeholder' => 'Escriba lo que quiere buscar','type' => 'text','wire:model' => 'search']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'flex-1 mx-4','placeholder' => 'Escriba lo que quiere buscar','type' => 'text','wire:model' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.create-service')->html();
} elseif ($_instance->childHasBeenRendered('l1746820220-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1746820220-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1746820220-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1746820220-0');
} else {
    $response = \Livewire\Livewire::mount('admin.create-service');
    $html = $response->html();
    $_instance->logRenderedChild('l1746820220-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
                
             
            </div>
            <?php if(count($posts)): ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col"
                                class="px-6 w-24 cursor-pointer py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                wire:click="order('id')">
                                Id
                                

                                <?php if($sort == 'id'): ?>
                                    <?php if($direction == 'asc'): ?>
                                        <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>
                            </th>
                            <th scope="col"
                                class="px-6 cursor-pointer py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                wire:click="order('title')">
                                Titulo

                                

                                <?php if($sort == 'title'): ?>
                                    <?php if($direction == 'asc'): ?>
                                        <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>

                            </th>
                            <th scope="col"
                                class="px-6 cursor-pointer py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                wire:click="order('description')">
                                Contenido
                                <?php if($sort == 'description'): ?>
                                    <?php if($direction == 'asc'): ?>
                                        <i class="fas fa-sort-alpha-up-alt float-right mt-1"></i>
                                    <?php else: ?>
                                        <i class="fas fa-sort-alpha-down-alt float-right mt-1"></i>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <i class="fas fa-sort float-right mt-1"></i>
                                <?php endif; ?>
                            </th>
                            
                            <th scope="col" class="text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Acción
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr class="bg-<?php echo e($item->status==1 ? 'red' : 'green'); ?>-200 ">
                                <td class="px-6 py-4 ">
                                    <div class="text-sm text-gray-900 font-semibold"> <?php echo e($loop->index + 1); ?> </div>
                                </td>
                                <td class="px-6 py-4 ">
                                    <div class="text-sm text-gray-900 capitalize"><?php echo e($item->title); ?></div>
                                </td>
                                <td class="px-6 py-4 ">
                                    <div class="text-sm text-gray-900 capitalize"><?php echo e($item->description); ?></div>
                                </td>
                                <td class="px-6 py-4 flex text-sm font-medium">
                                    
                                    <a class="btn btn-green" wire:click="edit(<?php echo e($item); ?>)">
                                        <i class="fas fa-edit"></i></a>
                                    <a class="btn btn-red ml-2" wire:click="$emit('delete',<?php echo e($item->id); ?>)">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- More people... -->
                    </tbody>
                </table>
                <?php if($posts->hasPages()): ?>
                    <div class="px-6 py-3">
                        <?php echo e($posts->links()); ?>

                    </div>
                <?php endif; ?>

            <?php else: ?>
                <div class="px-6 py-4">
                    No existe ningún registro coincidente
                </div>

            <?php endif; ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dialog-modal','data' => ['wire:model' => 'open_edit']]); ?>
<?php $component->withName('jet-dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'open_edit']); ?>
         <?php $__env->slot('title', null, []); ?> 
            Editar el servicio
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('content', null, []); ?> 

            <div wire:loading wire:target="image"
                class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                <strong class="font-bold">
                    Imagen Cargando
                </strong>
                <span class="block sm:inline">Espere un momento hasta que la imagen se haya procesado..</span>
            </div>

            <?php if($image): ?>
                <img src="<?php echo e($image->temporaryUrl()); ?>" class="mb-4" alt="">

            <?php else: ?>
                <img src="<?php echo e(Storage::url($post->image)); ?>" alt="">
            <?php endif; ?>

            <div class="mt-4">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['value' => 'Titulo del servicio']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => 'Titulo del servicio']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['wire:model' => 'post.title','type' => 'text','class' => 'w-full']]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'post.title','type' => 'text','class' => 'w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>

            <div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['value' => 'Contenido del servicio']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => 'Contenido del servicio']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <textarea wire:model="post.description" class="w-full form-control" rows="6"></textarea>
            </div>
            <div class="bg-white shadow-xl rounded-lg p-6 mb-4">
                <p class="font-semibold mb-2">Estado del servicio</p>
            
                <div class="flex">
                    <label class="mr-6">
                        <input wire:model="post.status" type="radio" name="status" value="1">
                        Oculto
                    </label>
                    <label>
                        <input wire:model="post.status" type="radio" name="status" value="2">
                        Publicado
                    </label>
                </div>
            
            </div>
            <div class="mb-4">
                <input type="file" wire:model="image" id="<?php echo e($identificador); ?>">
            </div>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['wire:click' => '$set(\'open_edit\', false)','class' => 'mr-4']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open_edit\', false)','class' => 'mr-4']); ?>
                Cancelar
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['wire:click' => 'update','wire:loadin.attr' => 'disabled:opacity-25']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'update','wire:loadin.attr' => 'disabled:opacity-25']); ?>
                Actualizar Post
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


</div>

<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\resources\views/livewire/admin/show-service.blade.php ENDPATH**/ ?>