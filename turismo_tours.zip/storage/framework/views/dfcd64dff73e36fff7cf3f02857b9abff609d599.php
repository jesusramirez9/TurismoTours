<?php echo e($slot); ?>

<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Turismo_tours\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>