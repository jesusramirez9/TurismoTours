<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WebhooksController extends Controller
{
    //
    public function __invoke(Request $request)
    {
        
    }
}
