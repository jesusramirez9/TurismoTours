<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class EditPost extends Component
{
    public function render()
    {
        return view('livewire.admin.edit-post');
    }
}
